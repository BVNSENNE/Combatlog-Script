-----------------------------------
-- Leaked by user1091337452#0921 --
-----------------------------------


print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')
print('Leaked by user1091337452#0921')





ESX = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent("esx:getSharedObject", function(leaked) 
			ESX = leaked 
		end)
		Citizen.Wait(500)
	end
end)

RegisterCommand('combatlog', function()
        TriggerEvent('leaked:sendcombatcache')
        TriggerEvent('leaked:getcombatcache')
end)

local combatcache = {}
local data = 
RegisterNetEvent('leaked:sendcombatcache')
AddEventHandler('leaked:sendcombatcache', function(data, time, key)
	table.insert(combatcache, { 
        time = time, 
        attackerId = data.attackerId, 
        victimId = data.victimId, 
        attackerPedId = data.attackerPedId, 
        victimPedId = data.victimPedId, 
        health = data.health, 
        newHealth = data.newHealth,
        distance = data.distance, 
        speedAttacker = data.speedAttacker,
        speedVictim = data.speedVictim,
        weapon = data.weapon,
        bone = data.bone
    })
end)

RegisterNetEvent('leaked:getcombatcache')
AddEventHandler('leaked:getcombatcache', function(source, currenttime, key)
    exports['esx_rpchat']:printToChat('combatlog', 'Combat log is naar je console geprint ^2(F8)')
	local defaultmsg = ("attacker       victim      where                             damage       oldhealth    newHealth       distance       weapon                                     a. speed      v. speed    time")
	TriggerEvent("chat:serverPrint", defaultmsg)
    for k,v in pairs(combatcache) do
        if sourcee == v.attackerId or sourcee == v.victimId then
			local atack = math.floor(v.attackerPedId)
			local devend = math.floor(v.victimPedId)
			if sourcee == v.attackerId then
				atack = "me"
			end
			if sourcee == v.victimId then
				devend = "me"
			end

            attackid = string.format("%-15s", tostring(atack))
            victimid = string.format("%-12s", tostring(devend))
            damage = string.format("%-13s", tostring(math.floor(v.health - v.newHealth)))
            oldhealth = string.format("%-13s", tostring(math.floor(v.health)))
            newhealth = string.format("%-16s", tostring(math.floor(v.newHealth)))
            distance = string.format("%-15s", tostring(math.floor(v.distance)))
            timeago = string.format("%-10s", tostring(math.floor(currenttime - v.time)))
            aspeed = string.format("%-14s", tostring(math.floor(v.speedAttacker)))
            vspeed = string.format("%-12s", tostring(math.floor(v.speedVictim)))
            weapon = string.format("%-43s", tostring(v.weapon))
            bone = string.format("%-34s", tostring(v.bone))
            local msg = ("%s%s%s%s%s%s%s%s%s%s%s"):format(attackid, victimid, bone, damage, oldhealth, newhealth, distance, weapon, aspeed, vspeed, timeago)
			TriggerEvent("chat:serverPrint", msg)
        end
    end
end)