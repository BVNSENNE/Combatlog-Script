


fx_version 'bodacious'
games {'gta5'}

client_script 'client.lua'


